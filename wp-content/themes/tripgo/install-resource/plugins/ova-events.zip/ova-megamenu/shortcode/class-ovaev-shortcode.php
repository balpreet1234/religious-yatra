<?php defined( 'ABSPATH' ) || exit;

require_once( 'ovaev-shortcode-simple-calendar.php' );
require_once( 'ovaev-shortcode-fullcalendar.php' );
require_once( 'ovaev-shortcode-slide.php' );
require_once( 'ovaev-shortcode-slide-ajax.php' );
require_once( 'ovaev-shortcode-search-ajax.php' );
require_once( 'ovaev-shortcode-thumbnail.php' );
require_once( 'ovaev-shortcode-title.php' );
require_once( 'ovaev-shortcode-date.php' );
require_once( 'ovaev-shortcode-time.php' );
require_once( 'ovaev-shortcode-location.php' );
require_once( 'ovaev-shortcode-categories.php' );
require_once( 'ovaev-shortcode-content.php' );
require_once( 'ovaev-shortcode-tabs.php' );
require_once( 'ovaev-shortcode-tags.php' );
require_once( 'ovaev-shortcode-share.php' );
require_once( 'ovaev-shortcode-related.php' );
require_once( 'ovaev-shortcode-event-filter.php' );