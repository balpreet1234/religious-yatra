<?php if ( !defined( 'ABSPATH' ) ) exit(); ?>

<div class="image">
	<?php the_post_thumbnail(); ?>
</div>